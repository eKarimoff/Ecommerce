<div>
    User Dashboard
</div>
<?php /**PATH D:\OpenServer\domains\ecommerce\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>